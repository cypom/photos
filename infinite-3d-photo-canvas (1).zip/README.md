# Infinite 3D Photo Canvas

A minimal recreation of the core interaction style of the reference
`edoardolunardi/infinite-canvas` project.

This version intentionally removes:
- article / introduction UI
- external artwork data
- navigation chrome
- text overlays

It keeps the interaction concept:
- 3D perspective photo field
- free pointer dragging
- inertial movement
- wheel / trackpad depth movement
- touch pinch zoom
- repeated spatial field for an effectively infinite canvas
- placeholder cards ready to become real photos

## Run

```bash
npm install
npm run dev
```

Then open the local Vite URL.

## Build

```bash
npm run build
```

## Replace placeholders with real photos

The current cards use a clean light-gray material.

When you are ready to use photos, add files such as:

```text
public/
  photos/
    photo-01.jpg
    photo-02.jpg
```

Then change `PHOTO_ITEMS` in `src/main.jsx`:

```js
{ 
  id: 0,
  width: 3.7,
  height: 2.7,
  x: -5.2,
  y: 2.4,
  z: -2.0,
  src: "/photos/photo-01.jpg"
}
```

Then change the `PhotoCard` call from:

```js
src: null
```

to:

```js
src: item.src
```

The texture loader is already included.

## Main tuning values

At the top of `src/main.jsx`:

- `LOOP_X / LOOP_Y / LOOP_Z`: density and repeat size
- `CAMERA.panStrength`: drag sensitivity
- `CAMERA.wheelStrength`: depth / zoom sensitivity
- `CAMERA.friction`: horizontal/vertical inertia
- `CAMERA.zoomFriction`: depth inertia
- `CAMERA.startZ`: initial camera distance
- `camera.fov`: perspective strength

The layout of the placeholder photos is controlled by `PHOTO_ITEMS`.

## GitHub

Create an empty GitHub repository, then upload the project files:

```bash
git init
git add .
git commit -m "Create infinite 3D photo canvas"
git branch -M main
git remote add origin https://github.com/YOUR_NAME/YOUR_REPO.git
git push -u origin main
```
