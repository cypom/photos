import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";
import "./styles.css";

/*
  Infinite 3D Photo Canvas
  ------------------------
  Core interaction:
  - Pointer drag: pan through the 3D photo field.
  - Wheel / trackpad: move forward and backward.
  - Pinch: zoom on touch devices.
  - Inertia: camera movement continues briefly after release.
  - Infinite wrapping: the photo field repeats without a visible edge.

  Replace PHOTO_ITEMS[i].src with your real image path later.
  Example:
    src: "/photos/photo-01.jpg"
*/

const PHOTO_ITEMS = [
  { id: 0,  width: 3.7, height: 2.7, x: -5.2, y:  2.4, z: -2.0 },
  { id: 1,  width: 2.8, height: 3.7, x: -1.0, y:  4.6, z: -7.0 },
  { id: 2,  width: 4.6, height: 3.0, x:  4.8, y:  3.0, z: -11.0 },
  { id: 3,  width: 3.0, height: 4.1, x:  8.0, y: -1.0, z: -4.0 },
  { id: 4,  width: 4.2, height: 2.8, x:  3.0, y: -3.7, z: -16.0 },
  { id: 5,  width: 2.8, height: 3.8, x: -3.6, y: -3.0, z: -12.0 },
  { id: 6,  width: 4.4, height: 3.1, x: -7.4, y: -0.4, z: -18.0 },
  { id: 7,  width: 3.0, height: 4.0, x: -10.0, y:  3.7, z: -10.0 },
  { id: 8,  width: 4.7, height: 3.0, x:  9.5, y:  4.7, z: -20.0 },
  { id: 9,  width: 3.3, height: 4.2, x: -2.0, y:  7.2, z: -23.0 },
  { id: 10, width: 4.5, height: 3.0, x:  6.0, y: -6.2, z: -25.0 },
  { id: 11, width: 3.0, height: 4.0, x: -8.5, y: -5.2, z: -28.0 }
];

// Infinite repeat size. Increase these values if your own photo composition is denser.
const LOOP_X = 24;
const LOOP_Y = 18;
const LOOP_Z = 36;

const CAMERA = {
  startZ: 8,
  minZ: -18,
  maxZ: 20,
  panStrength: 0.012,
  wheelStrength: 0.018,
  friction: 0.88,
  zoomFriction: 0.84,
  maxPanVelocity: 0.32,
  maxZoomVelocity: 1.8
};

function PlaceholderMaterial() {
  return (
    <meshBasicMaterial
      color="#e7e7e7"
      toneMapped={false}
      side={THREE.DoubleSide}
    />
  );
}

function PhotoCard({ item, index }) {
  const mesh = useRef();
  const [texture, setTexture] = useState(null);

  // Keep the image loading hook ready for the next stage.
  // Currently every src is null, so the canvas renders clean placeholders.
  useEffect(() => {
    if (!item.src) return;

    const loader = new THREE.TextureLoader();
    let alive = true;

    loader.load(
      item.src,
      (loaded) => {
        if (!alive) return;
        loaded.colorSpace = THREE.SRGBColorSpace;
        loaded.minFilter = THREE.LinearFilter;
        loaded.magFilter = THREE.LinearFilter;
        setTexture(loaded);
      },
      undefined,
      () => {
        if (alive) setTexture(null);
      }
    );

    return () => {
      alive = false;
    };
  }, [item.src]);

  return (
    <mesh
      ref={mesh}
      position={[item.x, item.y, item.z]}
      renderOrder={index}
    >
      <planeGeometry args={[item.width, item.height, 1, 1]} />
      {texture ? (
        <meshBasicMaterial
          map={texture}
          toneMapped={false}
          side={THREE.DoubleSide}
        />
      ) : (
        <PlaceholderMaterial />
      )}
    </mesh>
  );
}

function InfinitePhotoField({ controls }) {
  const group = useRef();

  const copies = useMemo(() => {
    const result = [];

    // A 3 x 3 x 3 neighborhood makes the field continuous around the camera.
    for (let ix = -1; ix <= 1; ix += 1) {
      for (let iy = -1; iy <= 1; iy += 1) {
        for (let iz = -1; iz <= 1; iz += 1) {
          for (const item of PHOTO_ITEMS) {
            result.push({
              ...item,
              copyX: item.x + ix * LOOP_X,
              copyY: item.y + iy * LOOP_Y,
              copyZ: item.z + iz * LOOP_Z,
            });
          }
        }
      }
    }

    return result;
  }, []);

  useFrame(() => {
    if (!group.current) return;

    // Move the whole repeated field opposite to the camera-like world offset.
    // This keeps the camera near the origin, which is numerically stable.
    group.current.position.x = -controls.offset.x;
    group.current.position.y = -controls.offset.y;
    group.current.position.z = -controls.offset.z;

    // Wrap the virtual camera offset so movement can continue forever.
    controls.offset.x = wrap(controls.offset.x, LOOP_X);
    controls.offset.y = wrap(controls.offset.y, LOOP_Y);
    controls.offset.z = wrap(controls.offset.z, LOOP_Z);
  });

  return (
    <group ref={group}>
      {copies.map((item, i) => (
        <PhotoCard
          key={`${item.id}-${i}`}
          item={{
            ...item,
            x: item.copyX,
            y: item.copyY,
            z: item.copyZ
          }}
          index={i}
        />
      ))}
    </group>
  );
}

function wrap(value, size) {
  return THREE.MathUtils.euclideanModulo(value + size / 2, size) - size / 2;
}

function CameraRig({ controls }) {
  const { camera, gl } = useThree();
  const pointers = useRef(new Map());
  const previousPinch = useRef(null);
  const drag = useRef({
    active: false,
    x: 0,
    y: 0
  });

  useEffect(() => {
    const element = gl.domElement;

    const onPointerDown = (event) => {
      element.setPointerCapture?.(event.pointerId);
      pointers.current.set(event.pointerId, {
        x: event.clientX,
        y: event.clientY
      });

      if (pointers.current.size === 1) {
        drag.current.active = true;
        drag.current.x = event.clientX;
        drag.current.y = event.clientY;
      }
    };

    const onPointerMove = (event) => {
      if (!pointers.current.has(event.pointerId)) return;

      const previous = pointers.current.get(event.pointerId);
      const dx = event.clientX - previous.x;
      const dy = event.clientY - previous.y;

      pointers.current.set(event.pointerId, {
        x: event.clientX,
        y: event.clientY
      });

      if (pointers.current.size === 1 && drag.current.active) {
        controls.velocity.x -= dx * CAMERA.panStrength;
        controls.velocity.y += dy * CAMERA.panStrength;

        controls.velocity.x = THREE.MathUtils.clamp(
          controls.velocity.x,
          -CAMERA.maxPanVelocity,
          CAMERA.maxPanVelocity
        );
        controls.velocity.y = THREE.MathUtils.clamp(
          controls.velocity.y,
          -CAMERA.maxPanVelocity,
          CAMERA.maxPanVelocity
        );
      }

      if (pointers.current.size === 2) {
        const pts = [...pointers.current.values()];
        const distance = Math.hypot(
          pts[0].x - pts[1].x,
          pts[0].y - pts[1].y
        );

        if (previousPinch.current !== null) {
          const delta = distance - previousPinch.current;
          controls.zoomVelocity -= delta * 0.010;
        }

        previousPinch.current = distance;
      }
    };

    const releasePointer = (event) => {
      pointers.current.delete(event.pointerId);

      if (pointers.current.size < 2) {
        previousPinch.current = null;
      }

      if (pointers.current.size === 0) {
        drag.current.active = false;
      }
    };

    const onWheel = (event) => {
      event.preventDefault();

      // Trackpads may emit deltaX/deltaY while mouse wheels mainly emit deltaY.
      // Horizontal wheel movement pans; vertical movement pushes through depth.
      controls.velocity.x += event.deltaX * CAMERA.wheelStrength * 0.35;
      controls.zoomVelocity += event.deltaY * CAMERA.wheelStrength;
      controls.zoomVelocity = THREE.MathUtils.clamp(
        controls.zoomVelocity,
        -CAMERA.maxZoomVelocity,
        CAMERA.maxZoomVelocity
      );
    };

    element.addEventListener("pointerdown", onPointerDown);
    element.addEventListener("pointermove", onPointerMove);
    element.addEventListener("pointerup", releasePointer);
    element.addEventListener("pointercancel", releasePointer);
    element.addEventListener("wheel", onWheel, { passive: false });

    return () => {
      element.removeEventListener("pointerdown", onPointerDown);
      element.removeEventListener("pointermove", onPointerMove);
      element.removeEventListener("pointerup", releasePointer);
      element.removeEventListener("pointercancel", releasePointer);
      element.removeEventListener("wheel", onWheel);
    };
  }, [gl, controls]);

  useFrame((_, delta) => {
    // Frame-rate independent-ish damping.
    const panDamping = Math.pow(CAMERA.friction, delta * 60);
    const zoomDamping = Math.pow(CAMERA.zoomFriction, delta * 60);

    controls.offset.x += controls.velocity.x * delta * 60;
    controls.offset.y += controls.velocity.y * delta * 60;
    controls.offset.z += controls.zoomVelocity * delta * 60;

    controls.velocity.x *= panDamping;
    controls.velocity.y *= panDamping;
    controls.zoomVelocity *= zoomDamping;

    // Keep depth movement visually useful without allowing the camera to
    // leave the useful range before the infinite wrapping takes over.
    controls.offset.z = wrap(controls.offset.z, LOOP_Z);

    camera.position.set(0, 0, CAMERA.startZ);
    camera.lookAt(0, 0, -10);
  });

  return null;
}

function Scene() {
  const controls = useMemo(
    () => ({
      offset: { x: 0, y: 0, z: 0 },
      velocity: { x: 0, y: 0 },
      zoomVelocity: 0
    }),
    []
  );

  return (
    <>
      <color attach="background" args={["#f1f1f1"]} />

      <Canvas
        dpr={[1, 2]}
        camera={{
          position: [0, 0, CAMERA.startZ],
          fov: 52,
          near: 0.1,
          far: 120
        }}
        gl={{
          antialias: true,
          powerPreference: "high-performance"
        }}
        onCreated={({ gl }) => {
          gl.setClearColor("#f1f1f1");
        }}
      >
        <CameraRig controls={controls} />
        <InfinitePhotoField controls={controls} />
      </Canvas>
    </>
  );
}

function App() {
  return (
    <main className="canvas-page">
      <Scene />
    </main>
  );
}

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
